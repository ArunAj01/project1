package testingDemo;

import org.openqa.selenium.chrome.ChromeDriver;

public class TestingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://facebook.com");

	}

}
